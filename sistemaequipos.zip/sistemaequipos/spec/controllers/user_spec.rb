# spec/models/equipo_spec.rb
require 'rails_helper'

RSpec.describe Equipo, type: :model do
  it 'validates presence of nombre' do
    equipo = Equipo.new(nombre: 'Nombre de Ejemplo') # Proporciona un valor para nombre
    expect(equipo).to be_valid
  end
end

