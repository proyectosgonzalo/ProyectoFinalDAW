// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
// app/javascript/packs/application.js

import 'bootstrap';
import "@hotwired/turbo-rails";
import "controllers";
import "jquery3";
import "popper";
import "bootstrap";
import "turbolinks";
import "rails-ujs";
import "activestorage";
import_tree .;


