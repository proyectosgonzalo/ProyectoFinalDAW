class ApplicationRecord < ActiveRecord::Base
  primary_abstract_class
  validates :nombre, length: { maximum: 10 }
  validates :ip, length: { maximum: 12 }
  validates :mac, length: { maximum: 17 }
  validates :observaciones, length: { maximum: 100 }
  
end


