# app/models/equipo.rb

class Equipo < ApplicationRecord
  # Pueden haber otras definiciones aquí
end
