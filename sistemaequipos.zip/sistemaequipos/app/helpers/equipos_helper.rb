module EquiposHelper
end
