# app/controllers/equipos_controller.rb

class EquiposController < ApplicationController
  def index
    # Puedes agregar lógica adicional aquí si es necesario
  end

  def gestion
    # Puedes agregar lógica adicional aquí si es necesario
  end
  def destroy
    @equipo = Equipo.find(params[:id])
    @equipo.destroy

    flash[:notice] = 'Equipo eliminado exitosamente.'
    redirect_to trabajo_equipos_path
  end

  def trabajo_equipos
    @equipos = Equipo.all
  end

  def login
    usuario = params[:usuario]
    contrasena = params[:contrasena]

    if usuario == 'admin' && contrasena == 'admin'
      # Las credenciales son válidas, redirigir a la página de trabajo equipos
      redirect_to trabajo_equipos_path
    else
      # Las credenciales no son válidas, mostrar mensaje de error
      flash[:alert] = 'Credenciales incorrectas. Intenta de nuevo.'
      logger.info("Redirigiendo a gestion_equipos_path después de credenciales incorrectas")
      redirect_to gestion_equipos_path
    end
  end

  def edit
    @equipo = Equipo.find(params[:id])
  end

  def new
    @equipo = Equipo.new
  end

  def create
    @equipo = Equipo.new(equipo_params)

    if @equipo.save
      flash[:notice] = 'Equipo creado exitosamente.'
      redirect_to trabajo_equipos_path
    else
      render :new
    end
  end

  def update
    @equipo = Equipo.find(params[:id])

    if @equipo.update(equipo_params)
      flash[:notice] = 'Equipo actualizado exitosamente.'
      redirect_to trabajo_equipos_path
    else
      render :edit
    end
  end

  private

  def find_equipo
    # Lógica para encontrar el equipo específico, por ejemplo:
    @equipo = Equipo.find_by(id: params[:id])
    if @equipo.nil?
      flash[:alert] = 'Equipo no encontrado.'
      redirect_to trabajo_equipos_path
    end
    @equipo
  end

  def equipo_params
    params.require(:equipo).permit(:nombre, :ip, :mac, :observaciones)
  end
end



  
  




