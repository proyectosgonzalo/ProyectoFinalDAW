# config/routes.rb

Rails.application.routes.draw do
  root 'equipos#index'
  get '/trabajo_equipos', to: 'equipos#trabajo_equipos', as: 'trabajo_equipos'
  post '/login', to: 'equipos#login', as: 'equipos_login'

  resources :equipos do
  member do
    get 'edit'
    delete 'destroy', to: 'equipos#destroy', as: 'destroy_equipo'
  end
  get 'gestion', on: :collection
end

end



