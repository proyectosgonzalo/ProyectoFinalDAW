class CreateEquipos < ActiveRecord::Migration[7.0]
  def change
    create_table :equipos do |t|
      t.string :nombre
      t.string :ip
      t.string :mac
      t.text :observaciones

      t.timestamps
    end
  end
end
